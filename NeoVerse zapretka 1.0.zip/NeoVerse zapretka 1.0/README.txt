🛠 Поддержка и баг‑репорты
Если вы столкнулись с ошибками или багами приложения (но не ОС), пожалуйста, сообщите нам:
• 	Discord-сервер: http://discord.com/invite/sQ4pqzGJcs
• 	Репорты багов: через канал #feedback или лично на сервере
• 	Только по приложению! Краш системы, драйверов или Windows — не рассматриваются

❤️ Поддержать проект
• 	Донаты: http://www.donationalerts.com/r/NeoNesh
• 	YouTube-канал: http://www.youtube.com/@NeoNesh_offical
